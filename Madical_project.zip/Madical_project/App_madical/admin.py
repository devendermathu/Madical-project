from django.contrib import admin
from App_madical.models import *
# Register your models here.

admin.site.register(order)
admin.site.register(Person_information)
admin.site.register(Instock)