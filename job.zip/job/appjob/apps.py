from django.apps import AppConfig


class AppjobConfig(AppConfig):
    name = 'appjob'
